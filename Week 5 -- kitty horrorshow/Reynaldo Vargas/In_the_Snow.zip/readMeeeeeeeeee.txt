In The Snow//Goodbye Moon
by: doggy comedyhide

Poem written by Karina Popp.
All Sounds taken from freesfx.co.uk
Heart Model from http://tf3dm.com/
Everything else primitives or basic Unity Assets


Play until you board the space ship

